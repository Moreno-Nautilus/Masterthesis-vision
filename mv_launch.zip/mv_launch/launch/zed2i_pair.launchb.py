from __future__ import annotations

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory


def generate_launch_description() -> LaunchDescription:
    camera_model = LaunchConfiguration("camera_model")
    cam1_name = LaunchConfiguration("cam1_name")
    cam2_name = LaunchConfiguration("cam2_name")

    zed_wrapper_share = get_package_share_directory("zed_wrapper")
    zed_launch = f"{zed_wrapper_share}/launch/zed_camera.launch.py"

    cam1 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(zed_launch),
        launch_arguments={
            "camera_model": camera_model,
            "serial_number": "36829049",
            "camera_name": cam1_name,
	    "ros_params_override_path": "/home/moreno/zed_ros2_ws/src/mv_launch/config/zed_override_native.yaml",	
        }.items(),
    )

    cam2 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(zed_launch),
        launch_arguments={
            "camera_model": camera_model,
            "ros_params_override_path": "/home/moreno/zed_ros2_ws/src/mv_launch/config/zed_override_native.yaml",
	    "camera_name": cam2_name,
	    "serial_number": "38580376",
        }.items(),
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("camera_model", default_value="zed2i"),
            DeclareLaunchArgument("cam1_name", default_value="zed2i_1"),
            DeclareLaunchArgument("cam2_name", default_value="zed2i_2"),
            cam1,
            cam2,
        ]
    )
