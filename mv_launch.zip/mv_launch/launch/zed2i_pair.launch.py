from __future__ import annotations

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory


def generate_launch_description() -> LaunchDescription:
    cam1_model = LaunchConfiguration("cam1_model")
    cam2_model = LaunchConfiguration("cam2_model")
    cam3_model = LaunchConfiguration("cam3_model")

    cam1_name = LaunchConfiguration("cam1_name")
    cam2_name = LaunchConfiguration("cam2_name")
    cam3_name = LaunchConfiguration("cam3_name")

    zed_wrapper_share = get_package_share_directory("zed_wrapper")
    zed_launch = f"{zed_wrapper_share}/launch/zed_camera.launch.py"

    override_path = "/home/pdzuser/zed_ros2_ws/src/mv_launch/config/zed_override_native.yaml"

    cam1 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(zed_launch),
        launch_arguments={
            "camera_model": cam1_model,
            "serial_number": "39725782",
            "camera_name": cam1_name,
            "ros_params_override_path": override_path,
        }.items(),
    )

    cam2 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(zed_launch),
        launch_arguments={
            "camera_model": cam2_model,
            "serial_number": "38580376",
            "camera_name": cam2_name,
            "ros_params_override_path": override_path,
        }.items(),
    )

    cam3 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(zed_launch),
        launch_arguments={
            "camera_model": cam3_model,
            "serial_number": "33137761",
            "camera_name": cam3_name,
            "ros_params_override_path": override_path,
        }.items(),
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("cam1_model", default_value="zed2i"),
            DeclareLaunchArgument("cam2_model", default_value="zed2i"),
            DeclareLaunchArgument("cam3_model", default_value="zed2i"),
            DeclareLaunchArgument("cam1_name", default_value="zed2i_1"),
            DeclareLaunchArgument("cam2_name", default_value="zed2i_2"),
            DeclareLaunchArgument("cam3_name", default_value="zed2i_3"),
            cam1,
            cam2,
            cam3,
        ]
    )
