from __future__ import annotations

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node, ComposableNodeContainer
from launch_ros.descriptions import ComposableNode
from ament_index_python.packages import get_package_share_directory


def generate_launch_description() -> LaunchDescription:
    """1 static ZED2i + 2 end-effector-mounted RealSense cameras.

    Mirrors zed2i_pair.launch.py for the ZED camera (same override yaml,
    same include pattern), and includes realsense2_camera's own rs_launch.py
    once per RealSense device, matched by serial number so the same physical
    camera always comes up as the same cam_id regardless of USB enumeration
    order. Topic names produced here (namespace/name = realsense_1 /
    realsense_2) must match ALL_CAMERAS in
    run_pipeline_track_multicam_realsense.py.

    Also starts TWO flange_pose_publisher instances, one per arm of the
    dual-LBR rig: realsense_1 is bolted to the LEFT arm and realsense_2 to
    the RIGHT arm (see ALL_CAMERAS in run_pipeline_track_multicam_realsense.py
    for that mapping and which robot_bases.yaml key each corresponds to).
    This is a dual-arm bringup (lbr_dual_arm_bringup, robot_description
    built from lbr_dual_arm_description/urdf/lbr_dual_arm.xacro), which
    prefixes every link with the per-arm robot_name -- there is no plain
    "lbr_link_0"/"lbr_link_ee" frame, only "lbr_one_link_0"/"lbr_one_link_ee"
    (left) and "lbr_two_link_0"/"lbr_two_link_ee" (right). Each publisher
    does a tf2 lookup of its own arm's base->flange transform and republishes
    it as geometry_msgs/PoseStamped on /left/ee_pose or /right/ee_pose. This
    is what the pipeline's MultiCamGrabberRealsense composes with each
    RealSense camera's static camera-to-flange offset to get its live
    camera-to-base extrinsic. Requires the dual-arm hardware.launch.py (e.g.
    `ros2 launch lbr_dual_arm_bringup hardware.launch.py`) already running so
    robot_state_publisher + joint_state_broadcaster are publishing tf for
    both arms.

    Usage:
      ros2 launch mv_launch zed_realsense_trio.launch.py \
          rs1_serial:=<serial> rs2_serial:=<serial>

    Serial numbers are PLACEHOLDERS below (empty string = "first device
    found", which is fine with exactly one RealSense attached but will not
    reliably distinguish two). Find real serials once both cameras are
    plugged in via: rs-enumerate-devices | grep Serial
    """
    cam1_model = LaunchConfiguration("cam1_model")
    cam1_name = LaunchConfiguration("cam1_name")
    cam1_serial = LaunchConfiguration("cam1_serial")

    rs1_serial = LaunchConfiguration("rs1_serial")
    rs2_serial = LaunchConfiguration("rs2_serial")

    left_flange_base_frame = LaunchConfiguration("left_flange_base_frame")
    left_flange_frame = LaunchConfiguration("left_flange_frame")
    left_flange_pose_topic = LaunchConfiguration("left_flange_pose_topic")

    right_flange_base_frame = LaunchConfiguration("right_flange_base_frame")
    right_flange_frame = LaunchConfiguration("right_flange_frame")
    right_flange_pose_topic = LaunchConfiguration("right_flange_pose_topic")

    zed_wrapper_share = get_package_share_directory("zed_wrapper")
    zed_launch = f"{zed_wrapper_share}/launch/zed_camera.launch.py"

    realsense_share = get_package_share_directory("realsense2_camera")
    rs_launch = f"{realsense_share}/launch/rs_launch.py"

    override_path = "/home/pdzuser/zed_ros2_ws/src/mv_launch/config/zed_override_native.yaml"

    cam1 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(zed_launch),
        launch_arguments={
            "camera_model": cam1_model,
            "serial_number": cam1_serial,
            "camera_name": cam1_name,
            "ros_params_override_path": override_path,
        }.items(),
    )

    # Aligned depth so depth/rgb share one camera_info and pixel grid, same
    # as the ZED's depth_registered stream. Topics land under
    # /realsense_1/camera/... and /realsense_2/camera/... to match
    # ALL_CAMERAS in the realsense pipeline runner.
    realsense_1 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(rs_launch),
        launch_arguments={
            "camera_namespace": "realsense_1",
            "camera_name": "camera",
            "serial_no": ["'", rs1_serial, "'"],
            "enable_color": "true",
            "enable_depth": "true",
            "align_depth.enable": "true",
            "publish_tf": "true",
        }.items(),
    )

    realsense_2 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(rs_launch),
        launch_arguments={
            "camera_namespace": "realsense_2",
            "camera_name": "camera",
            "serial_no": ["'", rs2_serial, "'"],
            "enable_color": "true",
            "enable_depth": "true",
            "align_depth.enable": "true",
            "publish_tf": "true",
        }.items(),
    )

    # The D405 color sensor has real (non-zero) Brown-Conrady distortion —
    # realsense2_camera does not rectify it, unlike the ZED wrapper's
    # rgb/color/rect/image (rectified in the ZED SDK before publishing). We
    # rectify it here with image_proc so every consumer of RealSense RGB
    # (SAM, DINO, FoundationPose, visualizers — all fed through View.rgb,
    # see src/perception/view.py) sees undistorted pixels, matching what
    # they already get from the ZED.
    #
    # aligned_depth_to_color is registered to the *distorted* color pixel
    # grid and its camera_info carries the same color distortion
    # coefficients (realsense2_camera derives it from the color intrinsics).
    # We rectify it too, through its own RectifyNode instance fed those same
    # coefficients, so color/image_rect and aligned_depth_to_color/image_rect
    # land back on one shared rectified pixel grid/intrinsics — required
    # because MultiCamGrabberRealsense backprojects depth using the DEPTH
    # camera_info's K (see _K_depth in multicam_grabber.py), so that K must
    # describe the same rectified grid depth/rgb are both now in.
    #
    # interpolation:=0 (cv::INTER_NEAREST) on the depth rectify node avoids
    # inventing blended foreground/background depth values along object
    # silhouettes; any pixels that land out-of-frame after undistortion
    # become NaN/invalid and are simply dropped from that camera's point
    # cloud — with 3 cameras fusing together this is a non-issue.
    def _rectify_container(cam_namespace: str) -> ComposableNodeContainer:
        return ComposableNodeContainer(
            name=f"{cam_namespace}_rectify_container",
            namespace=cam_namespace,
            package="rclcpp_components",
            executable="component_container",
            composable_node_descriptions=[
                ComposableNode(
                    package="image_proc",
                    plugin="image_proc::RectifyNode",
                    name="rectify_color_node",
                    namespace=cam_namespace,
                    remappings=[
                        ("image", "camera/color/image_raw"),
                        ("camera_info", "camera/color/camera_info"),
                        ("image_rect", "camera/color/image_rect"),
                    ],
                    parameters=[{"interpolation": 1}],
                ),
                ComposableNode(
                    package="image_proc",
                    plugin="image_proc::RectifyNode",
                    name="rectify_aligned_depth_node",
                    namespace=cam_namespace,
                    remappings=[
                        ("image", "camera/aligned_depth_to_color/image_raw"),
                        ("camera_info", "camera/aligned_depth_to_color/camera_info"),
                        ("image_rect", "camera/aligned_depth_to_color/image_rect"),
                    ],
                    parameters=[{"interpolation": 0}],
                ),
            ],
            output="screen",
        )

    realsense_1_rectify = _rectify_container("realsense_1")
    realsense_2_rectify = _rectify_container("realsense_2")

    left_flange_pose_publisher = Node(
        package="mv_launch",
        executable="flange_pose_publisher",
        name="flange_pose_publisher_left",
        parameters=[{
            "base_frame": left_flange_base_frame,
            "flange_frame": left_flange_frame,
            "output_topic": left_flange_pose_topic,
            "publish_rate_hz": 30.0,
        }],
    )

    right_flange_pose_publisher = Node(
        package="mv_launch",
        executable="flange_pose_publisher",
        name="flange_pose_publisher_right",
        parameters=[{
            "base_frame": right_flange_base_frame,
            "flange_frame": right_flange_frame,
            "output_topic": right_flange_pose_topic,
            "publish_rate_hz": 30.0,
        }],
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("cam1_model", default_value="zed2i"),
            DeclareLaunchArgument("cam1_name", default_value="zed2i_1"),
            # Whichever physical ZED2i is currently mounted/plugged in;
            # override with cam1_serial:=<serial> if it changes.
            DeclareLaunchArgument("cam1_serial", default_value="38580376"),
            # Known RealSense D405 units (see rs-enumerate-devices). Plain
            # values here — the single-quote wrapping that forces
            # realsense2_camera_node's serial_no parameter to load as a
            # string (not int) happens at the "serial_no": [...] site below,
            # not in this default, to avoid double-quoting.
            DeclareLaunchArgument("rs1_serial", default_value="260322275185"),
            DeclareLaunchArgument("rs2_serial", default_value="260522275434"),
            # Dual-arm frame names (lbr_dual_arm_description/urdf/lbr_dual_arm.xacro
            # prefixes every link with the arm's robot_name). See
            # flange_pose_publisher.py docstring for the "these are the pipeline's
            # base frame" assumption this relies on.
            DeclareLaunchArgument("left_flange_base_frame", default_value="lbr_one_link_0"),
            DeclareLaunchArgument("left_flange_frame", default_value="lbr_one_link_ee"),
            DeclareLaunchArgument("left_flange_pose_topic", default_value="/left/ee_pose"),
            DeclareLaunchArgument("right_flange_base_frame", default_value="lbr_two_link_0"),
            DeclareLaunchArgument("right_flange_frame", default_value="lbr_two_link_ee"),
            DeclareLaunchArgument("right_flange_pose_topic", default_value="/right/ee_pose"),
            cam1,
            realsense_1,
            realsense_2,
            realsense_1_rectify,
            realsense_2_rectify,
            left_flange_pose_publisher,
            right_flange_pose_publisher,
        ]
    )
