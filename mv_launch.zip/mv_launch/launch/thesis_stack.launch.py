from __future__ import annotations

import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    IncludeLaunchDescription,
    TimerAction,
)
from launch.conditions import IfCondition
from launch.launch_description_sources import (
    AnyLaunchDescriptionSource,
    PythonLaunchDescriptionSource,
)
from launch.substitutions import LaunchConfiguration


def generate_launch_description() -> LaunchDescription:
    start_foxglove = LaunchConfiguration("start_foxglove")
    start_perception = LaunchConfiguration("start_perception")
    docker_container_name = LaunchConfiguration("docker_container_name")
    perception_delay = LaunchConfiguration("perception_delay")
    foxglove_address = LaunchConfiguration("foxglove_address")
    foxglove_port = LaunchConfiguration("foxglove_port")

    mv_launch_share = get_package_share_directory("mv_launch")
    foxglove_share = get_package_share_directory("foxglove_bridge")

    zed_launch = os.path.join(mv_launch_share, "launch", "zed2i_pair.launch.py")
    foxglove_launch = os.path.join(
        foxglove_share, "launch", "foxglove_bridge_launch.xml"
    )

    perception_cmd = [
        "docker",
        "exec",
        "-i",
        docker_container_name,
        "bash",
        "-lc",
        (
            "source /opt/ros/humble/setup.bash && "
            "source /opt/ros-thesis-venv/bin/activate && "
            "cd /workspace/MasterThesis && "
            "python -m src.perception.ros.learn_runners.run_pipeline "
            "--tiny-objects-enabled "
            "--sam-max-image-side 1536 "
            "--cam2-sam-min-mask-area 20 "
            "--cam2-sam-min-bbox-side-px 3 "
            "--cam2-tiny-roi 700,500,1350,1080 "
            "--tiny-sam-max-image-side 1920 "
            "--tiny-sam-min-mask-area 8 "
            "--tiny-sam-min-bbox-side-px 2 "
            "--tiny-max-mask-area-ratio 0.01 "
            "--tiny-max-bbox-area-ratio 0.02"
        ),
    ]

    return LaunchDescription(
        [
            DeclareLaunchArgument("start_foxglove", default_value="true"),
            DeclareLaunchArgument("start_perception", default_value="true"),
            DeclareLaunchArgument("docker_container_name", default_value="thesis-newcuda"),
            DeclareLaunchArgument("perception_delay", default_value="8.0"),
            DeclareLaunchArgument("foxglove_address", default_value="0.0.0.0"),
            DeclareLaunchArgument("foxglove_port", default_value="8765"),

            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(zed_launch),
            ),

            IncludeLaunchDescription(
                AnyLaunchDescriptionSource(foxglove_launch),
                condition=IfCondition(start_foxglove),
                launch_arguments={
                    "address": foxglove_address,
                    "port": foxglove_port,
                }.items(),
            ),

            TimerAction(
                period=perception_delay,
                actions=[
                    ExecuteProcess(
                        condition=IfCondition(start_perception),
                        cmd=perception_cmd,
                        output="screen",
                        emulate_tty=True,
                    )
                ],
            ),
        ]
    )
