"""Republishes one arm's live base->flange transform as geometry_msgs/PoseStamped.

The Masterthesis-vision RealSense pipeline (run_pipeline_track_multicam_realsense.py)
needs the current flange pose every frame to compute the live extrinsic of each
end-effector-mounted RealSense camera:

    T_base_cam(t) = T_base_flange(t) @ T_flange_cam

No node in this workspace publishes that pose directly today — /lbr/state
(lbr_fri_idl/msg/LBRState) only carries raw joint angles, not a Cartesian pose.
This node instead reads the transform from tf2, published by robot_state_publisher
(driven by joint_state_broadcaster).

This is a DUAL-ARM rig (lbr_dual_arm_bringup, robot_description built from
lbr_dual_arm_description/urdf/lbr_dual_arm.xacro): every link is prefixed with
the arm's robot_name, so there is no plain "lbr_link_0"/"lbr_link_ee" frame --
only "lbr_one_link_0"/"lbr_one_link_ee" (left arm) and "lbr_two_link_0"/
"lbr_two_link_ee" (right arm). One instance of this node must be launched per
arm, with base_frame/flange_frame/output_topic parameters set accordingly (see
zed_realsense_trio.launch.py, which launches both instances on /left/ee_pose
and /right/ee_pose).

ASSUMPTION TO VERIFY: this node treats "<arm>_link_0" (that arm's own root
link) as coincident with the Masterthesis-vision pipeline's "base" frame for
that arm. That pipeline's "base" frame is defined operationally by the
checkerboard measurement in config/base_board_pose.yaml (translation_xyz_m is
"the checkerboard origin corner in robot base frame", entered by hand, not
derived from tf2). If that measurement was not taken relative to this arm's
link_0 specifically, this assumption is wrong and the published pose will be
offset by whatever fixed transform relates the two frames. Verify by comparing
a known point's pose under both conventions before trusting fused poses from
the RealSense cameras.
"""
from __future__ import annotations

import rclpy
from rclpy.node import Node
from rclpy.time import Time
from rclpy.duration import Duration
from geometry_msgs.msg import PoseStamped
from tf2_ros import Buffer, TransformListener, TransformException


class FlangePosePublisher(Node):
    def __init__(self) -> None:
        super().__init__("flange_pose_publisher")

        # No sane single-arm default in a dual-arm rig -- these MUST be
        # overridden per instance (see zed_realsense_trio.launch.py).
        self.declare_parameter("base_frame", "lbr_one_link_0")
        self.declare_parameter("flange_frame", "lbr_one_link_ee")
        self.declare_parameter("output_topic", "/left/ee_pose")
        self.declare_parameter("publish_rate_hz", 30.0)

        self.base_frame = self.get_parameter("base_frame").value
        self.flange_frame = self.get_parameter("flange_frame").value
        output_topic = self.get_parameter("output_topic").value
        rate_hz = float(self.get_parameter("publish_rate_hz").value)

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.pub = self.create_publisher(PoseStamped, output_topic, 10)

        self.get_logger().info(
            f"Publishing {self.base_frame} -> {self.flange_frame} as PoseStamped "
            f"on {output_topic} at {rate_hz:.1f} Hz "
            f"(ASSUMPTION: {self.base_frame} == Masterthesis-vision pipeline 'base' "
            f"frame — verify against config/base_board_pose.yaml before trusting "
            f"fused RealSense poses)"
        )

        self._timer = self.create_timer(1.0 / rate_hz, self._on_timer)

    def _on_timer(self) -> None:
        try:
            # Time() = latest available transform, not "now" — avoids racing
            # ahead of the tf tree and getting an extrapolation exception.
            tf = self.tf_buffer.lookup_transform(
                self.base_frame,
                self.flange_frame,
                Time(),
                timeout=Duration(seconds=0.05),
            )
        except TransformException as e:
            self.get_logger().warn(
                f"tf lookup {self.base_frame} -> {self.flange_frame} failed: {e}",
                throttle_duration_sec=2.0,
            )
            return

        msg = PoseStamped()
        msg.header.stamp = tf.header.stamp
        msg.header.frame_id = self.base_frame
        msg.pose.position.x = tf.transform.translation.x
        msg.pose.position.y = tf.transform.translation.y
        msg.pose.position.z = tf.transform.translation.z
        msg.pose.orientation = tf.transform.rotation
        self.pub.publish(msg)


def main() -> None:
    rclpy.init()
    node = FlangePosePublisher()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
